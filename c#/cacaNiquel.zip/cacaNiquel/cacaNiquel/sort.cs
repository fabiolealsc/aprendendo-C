﻿using System;
namespace cacaNiquel
{
    class sort
    {
        private Random r = new Random();
        public sort()
        {
           
        }
        public int sortei()
        {
            return r.Next(3);
        }
        
    }
}

