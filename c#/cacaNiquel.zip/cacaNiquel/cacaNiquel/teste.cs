﻿namespace cacaNiquel
{
    internal class teste
    {
        public bool test(string n1, string n2, string n3)
        {
            if (n1 == n2 && n2 == n3)
            {
                return true;
            }
            else
            {
                return false;
            }
               
        }
    }
}
